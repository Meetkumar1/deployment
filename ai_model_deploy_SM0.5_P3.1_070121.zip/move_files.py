import os
import shutil
import json


def execute():
    log = ""
    with open('files.json', 'r') as f:
        files = json.loads(f.read())
        for file in files:
            backup = file.get("backup_oldfile")
            source = file.get("source")
            destination = file.get("destination")
          
            if(backup):
                if os.path.exists(destination):
                    log = "baking up the file" + source + "\n"
                    os.replace(destination, destination + ".bak")

            if os.path.exists(source):
                if not os.path.exists(destination):
                    log = log + "file doesn't exist at this path: " + destination + "\n"
                    dir_path = os.path.dirname(destination)
                    if not os.path.exists(dir_path):
                        log = log + "dir doesn't exist at this path: " + dir_path + "\n"
                        log = log + "creating directory at this path: " + dir_path + "\n"
                        os.makedirs(dir_path)
                    
                log = log + "moving file" + source + "\n"
                shutil.move(source, destination)
            else:
                log = log + "source file does NOT exist: " + source

    return log


# execute()

# def execute():

#     if os.path.exists('/home/pi/alpha2/scooter_config.py'):
#         log = "baking up the file scooter_config.py \n"
#         os.replace("/home/pi/alpha2/scooter_config.py",
#                    "/home/pi/alpha2/scooter_config.py.bak")

#     log = log + "moving scooter_config.py file \n"
#     # os.replace("scooter_config.py", "/home/pi/alpha2/scooter_config.py")
#     shutil.copyfile("scooter_config.py", "/home/pi/alpha2/scooter_config.py")

#     if os.path.exists('/home/pi/alpha2/scooter.py'):
#         log = log + "baking up the file scooter.py \n"
#         os.replace("/home/pi/alpha2/scooter.py",
#                    "/home/pi/alpha2/scooter.py.bak")

#     log = log + "moving scooter.py file \n"
#     # os.replace("scooter.py", "/home/pi/alpha2/scooter.py")
#     shutil.copyfile("scooter.py", "/home/pi/alpha2/scooter.py")

#     log = log + "moving wave file \n"
#     #os.replace("power_up.wav", "/home/pi/alpha2/power_up.wav")
#     shutil.copyfile("power_up.wav", "/home/pi/alpha2/power_up.wav")
