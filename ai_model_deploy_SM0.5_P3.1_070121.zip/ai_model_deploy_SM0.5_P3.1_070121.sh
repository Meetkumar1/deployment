echo "Stop the scooter.service"
sudo systemctl kill scooter.service
sudo systemctl disable scooter.service

sudo systemctl kill lowpower_boot.service

echo "Change ownership from pp to pi"
sudo mkdir /home/pi/logs
sudo mkdir /home/pi/ppcli
sudo chown -R pp /home/pi/
sudo usermod -d /home/pi pp

echo "Start OTA deployment"
sudo killall python3
cd /home/pi/workspace/
sudo python3 install_ota.py

echo "mobileV2_SM_Train_0628_L100.tflite model exists or not"
ls -l /home/pi/alpha2/models | grep mobileV2_SM_Train_0628_L100.tflite
echo "mobileV2_All_Park_Train_0628_L100.tflite model exists or not"
ls -l /home/pi/alpha2/models | grep mobileV2_All_Park_Train_0628_L100.tflite