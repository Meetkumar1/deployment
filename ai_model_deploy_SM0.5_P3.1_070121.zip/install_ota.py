import os
import zipfile
import requests
import logging
import json
import move_files
import retro_commission as rc


DEVICE_ID_PATH = "/etc/pathpilot/device_id"
SERIAL_NUMBER_PATH = "/etc/pathpilot/serial_number"
SERIAL_NO_PATH = "/etc/pathpilot/serial_no"


try:
    logging.basicConfig(filename='remote-iot-update.log', level=logging.INFO)
except Exception as e:
    with open("remote-iot-update-critical.log", "w+") as log_file:
        log_file.write(e)
        log_file.write("\n")

def unzip_ota():
    try:
        with zipfile.ZipFile("/home/pi/workspace/ota.zip", 'r') as zip_ref:
            zip_ref.extractall("/home/pi/workspace/")
    except Exception as e:
        logging.critical("failed to unzip files")
        raise e


def get_file_content(file_path):
    if not os.path.exists(file_path):
        logging.critical(file_path + " - file does not exists")
        return ""
    elif os.path.getsize(file_path) == 0:
        logging.critical(file_path + " - no content found")
        return ""
    else:
        try:
            data = ""
            with open(file_path, "r") as file:
                data = file.read()

            return data.rstrip("\n")
        except Exception as e:
            logging.critical(file_path + " - error while reading the file")
            raise e

def set_device_id(device_id):
    try:

        filedata = ""
        # Read scooter_config.py file
        with open("/home/pi/alpha2/scooter_config.py", "r") as file:
            filedata = file.read()
            # Replace ######### with the device_id
            filedata = filedata.replace("##########", device_id)

        with open("/home/pi/alpha2/scooter_config.py", "w") as file:
            # Write the file out again
            file.write(filedata)

    except Exception as e:
        print("Error2: %s" % e)
        logging.critical("exception: %s" % e)

def set_serial_number(serial_number):
    try:

        filedata = ""
        # Read scooter_config.py file
        with open("/home/pi/alpha2/scooter_config.py", "r") as file:
            filedata = file.read()
            # Replace ######### with the device_id
            filedata = filedata.replace("9999999", str(int(serial_number)))

        with open("/home/pi/alpha2/scooter_config.py", "w") as file:
            # Write the file out again
            file.write(filedata)

    except Exception as e:
        print("Error2: %s" % e)
        logging.critical("exception: %s" % e)


def report_satus(serial_number, pi_serial, error_message, description, activity_name):
    url = "https://ib5cydr7he.execute-api.us-east-1.amazonaws.com/dev/activity"

    payload = json.dumps({
        "serial_number": serial_number,
        "pi_serial": pi_serial,
        "error_message": "NA" if error_message is None else error_message,
        "description": "NA" if description is None else description,
        "activity_name": activity_name
    })
    headers = {
        'Content-Type': 'application/json',
        'x-api-key': 'fTm2RKjPNnaM8qF5Mg0mK4skJXAGVG6E2lg3DHJQ',
        'X-Amz-Content-Sha256': 'beaead3198f7da1e70d03ab969765e0821b24fc913697e929e726aeaebf0eba3',
        'X-Amz-Date': '20210417T160739Z',
        'Authorization': 'AWS4-HMAC-SHA256 Credential=undefined/20210417/us-east-1/API gateway/aws4_request, SignedHeaders=content-type;host;x-amz-content-sha256;x-amz-date;x-api-key, Signature=ff2657f4657a84429ec15e690e5d274cbc028c59f4809d681f947bc62b217bfb'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    logging.info(response.text)


def get_pi_serial_number():
    return os.popen("cat /proc/cpuinfo | grep Serial").read().replace(
        '\t', '').replace('\n', '').replace('Serial:', '').strip()


def install():
    error_message = ''
    try:
        logging.info("getting serial_number.")
        serial_number = get_file_content(SERIAL_NO_PATH)
        if (serial_number is None or serial_number == ''):
            serial_number = get_file_content(SERIAL_NUMBER_PATH)
        serial_number = serial_number if serial_number else "NOT_FOUND"

        logging.info("getting pi_serial number.")
        pi_serial = get_pi_serial_number()
        pi_serial = pi_serial if pi_serial else "NOT_FOUND"
        logging.info("pi_serial: " + pi_serial)

        logging.info("getting device_id.")
        device_id = get_file_content(DEVICE_ID_PATH)
        device_id = device_id if device_id else "NOT_FOUND"
        logging.info("device_id: " + device_id)

        def is_valid(x): return x == "NOT_FOUND"
        if (is_valid(pi_serial) or is_valid(serial_number) or is_valid(device_id)):
            raise ValueError(
                'Looks like one of the important configuration params are not found on the device. Cannot proceed further')

        logging.info("Installing on serial_number: " + serial_number)


        logging.info("Calling retro commissioning service for serial_number: " + serial_number)
        logging.info(rc.execute(serial_number))

        logging.info("deploying files." + move_files.execute())

        logging.info("setting scooter_id / vehicle_id in config.")
        #set_device_id(device_id)
        set_serial_number(serial_number)
    except ValueError as e:
        logging.error(e)
        error_message = "Update failed."
    except Exception as e:
        logging.critical(e)
        error_message = "Update failed."
    finally:
        report_satus(serial_number, pi_serial, error_message,
                     get_file_content('remote-iot-update.log'), 'REMOTE_IOT_OTA_UPDATE')


install()
