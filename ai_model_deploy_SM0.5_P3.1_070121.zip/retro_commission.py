import os
import uuid
import requests
import json
import config as c
import re
import time

# def unlock_file(file_path):
#     os.popen(["sudo", "chmod", "755", file_path])

# def unlock_file(file_path):
#     os.popen()

def generate_ssh_public_key():
    if (not os.path.exists(c.DEVICE_KEY_PATH)):
        os.popen("sudo /home/pi/pptools/script/ecc608_read_keys.sh")
        os.popen("sudo chmod 444" + c.DEVICE_KEY_PATH)
        time.sleep(10)
        

    stream = os.popen("ssh-keygen -y -f " + c.DEVICE_KEY_PATH)
    return stream.read()


def is_guid_valid(guid_string):
    regex = re.compile('^[a-f0-9]{8}-?[a-f0-9]{4}-?4[a-f0-9]{3}-?[89ab][a-f0-9]{3}-?[a-f0-9]{12}\Z', re.I)
    match = regex.match(guid_string)
    return bool(match)

def set_file_value(file_path, val, name):
    log = ''
    if (val is None or val == ''):
        return 'Value for ' + name + ' is invalid.'

    existing_val = ''
    if (os.path.exists(file_path)):
        with open(file_path, 'r') as f:
            existing_val = f.read()
        
        if(existing_val != val):
            with open(file_path, 'w') as f:        
                f.write(val)
                log = 'Changed ' + name + ' FROM: ' + existing_val + ' TO: ' + val + '\n'
            
        else:
            log = name + ' is correctly set. Hence no change required.\n' 
    else:
        os.popen('sudo touch ' + file_path)
        os.popen('sudo chmod 755 ' + file_path)
        with open(file_path, 'w') as f:
            f.write(val)
            log = 'File ' + name + ' did NOT exist. Now created and value written : ' + val + '\n'
    
    os.popen('sudo chmod 444 ' + file_path)
    return log

def execute(serial_number):
    log = ''
    if(serial_number is None or serial_number == ''):
        log = log + ' serial_number does NOT exist on this device. \n'
        return log
    
    payload = json.dumps({'serial_number': serial_number})

    log = log + ' Get record for the serial_number: ' + serial_number + '\n'
    response = requests.request("GET", c.PUBLIC_KEY_URL, headers=c.PUBLIC_KEY_HEADERS, data=payload)
    results = json.loads(response.text)

    device_id = ''
    ssh_server_host = ''
    ssh_server_port = ''

    if(results is not None and len(results) > 0):
        result = results[0]
        device_id = result.get('device_id')
        ssh_server_host = result.get('ssh_server_host')
        ssh_server_port = result.get('ssh_server_port')

    if (not is_guid_valid(device_id)):
        return False

    log = log + set_file_value(c.DEVICE_ID_PATH, device_id, 'device_id')
    log = log + set_file_value(c.SSH_SERVER_HOST_PATH, ssh_server_host, 'ssh_server_host')
    log = log + set_file_value(c.SSH_SERVER_PORT_PATH, ssh_server_port, 'ssh_server_port')

    os.popen("ssh -i /var/ramdisk/keys/device_1.key  -f -N -R " + ssh_server_port + ":localhost:22 ubuntu@" + ssh_server_host)

    public_key = generate_ssh_public_key()

    log = log + '------ Generated Public Key ------- \n'
    log = log + public_key + '\n'
    payload = json.dumps({'serial_number': serial_number, 'public_key': public_key})
    log = log + payload + '\n'
    try: 
        response = requests.request("PUT", c.PUBLIC_KEY_URL, headers=c.PUBLIC_KEY_HEADERS, data=payload)
    except:
        log = log + 'Could not submit the publick key successfully'
    log = log + response.text 
    return log

