FILE1=/home/pi/alpha2/models/mobileV2_SM_Train_0628_L100.tflite
FILE2=/home/pi/alpha2/models/mobileV2_All_Park_Train_0628_L100.tflite

FILESIZE1=$(stat -c%s "$FILE1")
echo "Size of $FILE1 = $FILESIZE1 bytes."

FILESIZE2=$(stat -c%s "$FILE2")
echo "Size of $FILE2 = $FILESIZE2 bytes."

if [ -f "$FILE1" ] && [ -f "$FILE2" ] && (( FILESIZE1 == 8899412)) && (( FILESIZE2 == 8895072)); then
    echo "both $FILE1 $FILE2 exists."
    /home/pi/ppcli/report_status.sh "both models: $FILE1 $FILE2 exists" "model_upload_test" "na"
fi
