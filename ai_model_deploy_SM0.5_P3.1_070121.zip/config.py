DEVICE_KEY_PATH = '/var/ramdisk/keys/device_1.key' 
DEVICE_ID_PATH = '/etc/pathpilot/device_id'
SSH_SERVER_HOST_PATH = '/etc/pathpilot/ssh_server_host'
SSH_SERVER_PORT_PATH = '/etc/pathpilot/ssh_server_port'
SERIAL_NUMBER_PATH = '/etc/pathpilot/serial_number'


PUBLIC_KEY_URL = "https://izdlie0h9j.execute-api.us-east-1.amazonaws.com/dev/publickeys/"
PUBLIC_KEY_HEADERS = {
    'x-api-key': 'TNOOjpLo4W5CWK1Xfa66p8dwEJ61nsrfoGQKHDA6',
    'X-Amz-Date': '20210411T193530Z',
    'Authorization': 'AWS4-HMAC-SHA256 Credential=undefined/20210411/us-east-1/API gateway/aws4_request, SignedHeaders=host;x-amz-date;x-api-key, Signature=b950faa46ca583dd2ffa651ef18a330d0c1e00c45803a99ead4e7d0dc685e12b'
}